//
// Base64.h
//

#include <iostream>
#include <string>
#include <vector>

using namespace std;

///*
typedef unsigned char BYTE;
string base64_encode(BYTE const * buf, unsigned int bufLen);
vector<BYTE> base64_decode(string const&);
//*/

/*
const string b64encode(const void* data, const size_t &len);
const string b64decode(const void* data, const size_t &len);
string b64encode(const string& str);
string b64decode(const string& str64);
//*/
